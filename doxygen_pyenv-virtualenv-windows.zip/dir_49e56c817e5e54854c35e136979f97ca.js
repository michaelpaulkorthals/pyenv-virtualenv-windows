var dir_49e56c817e5e54854c35e136979f97ca =
[
    [ "build_doxygen_docs.bat", "build__doxygen__docs_8bat.html", null ],
    [ "open_doxygen_docs.bat", "open__doxygen__docs_8bat.html", null ]
];