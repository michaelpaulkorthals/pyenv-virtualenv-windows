var searchData=
[
  ['installation_0',['Installation',['../index.html#autotoc_md11',1,'']]],
  ['installed_20virtual_20environment_1',['Delete Installed Virtual Environment',['../index.html#autotoc_md26',1,'']]],
  ['installed_20virtual_20environments_2',['List Installed Virtual Environments',['../index.html#autotoc_md24',1,'']]],
  ['interface_3',['Plugin Interface',['../index.html#autotoc_md95',1,'']]],
  ['into_20main_20page_4',['Embed Code into Main Page',['../index.html#autotoc_md66',1,'']]],
  ['investigation_5',['Investigation',['../index.html#autotoc_md70',1,'']]]
];
