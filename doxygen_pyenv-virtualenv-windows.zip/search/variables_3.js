var searchData=
[
  ['data_0',['DATA',['../namespacetbl.html#a6fc19b4750c8bc159aac8bd142ef2a4d',1,'tbl']]],
  ['data_1',['data',['../classtbl_1_1_simple_table.html#a9222beb57f112b34a37f2a44bb76f924',1,'tbl::SimpleTable']]]
];
