var searchData=
[
  ['b_0',['B',['../index.html#autotoc_md73',1,'CON.8.A5 Secure System Design (B)'],['../index.html#autotoc_md74',1,'CON.8.A6 Use of External Libraries from Trusted Sources (B)']]],
  ['backup_1',['Data Backup',['../index.html#autotoc_md71',1,'']]],
  ['badges_2',['Badges',['../index.html#autotoc_md105',1,'']]],
  ['bash_3',['Linux BASH',['../index.html#autotoc_md107',1,'']]],
  ['bat_4',['Patching &quot;pyenv.bat&quot;',['../index.html#autotoc_md97',1,'']]],
  ['build_20package_5',['Build Package',['../index.html#autotoc_md88',1,'']]]
];
