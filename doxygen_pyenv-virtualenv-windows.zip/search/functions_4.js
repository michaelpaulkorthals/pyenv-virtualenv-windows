var searchData=
[
  ['error_0',['error',['../namespacelog.html#af03ee15774bc3090df52f35d17c6fddc',1,'log']]]
];
