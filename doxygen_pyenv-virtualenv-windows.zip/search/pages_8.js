var searchData=
[
  ['gimp_20graphic_20editor_0',['GIMP Graphic Editor',['../index.html#autotoc_md53',1,'']]],
  ['github_1',['Publication on GitHub',['../index.html#autotoc_md75',1,'']]],
  ['global_20python_20version_2',['Global Python Version',['../index.html#autotoc_md82',1,'']]],
  ['graphic_20editor_3',['GIMP Graphic Editor',['../index.html#autotoc_md53',1,'']]]
];
