var indexSectionsWithContent =
{
  0: "78_abcdefghilmnoprstuvwz",
  1: "s",
  2: "hlpt",
  3: "abcdhilmoprt",
  4: "_acdefgilmnprstuvw",
  5: "_bcdhlrstu",
  6: "fpvw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Pages"
};

