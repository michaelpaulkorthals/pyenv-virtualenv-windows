var searchData=
[
  ['unexpexcinfo_0',['UnexpExcInfo',['../namespacelog.html#a6a725fca266139bc8f04cd0d738a7aad',1,'log']]]
];
