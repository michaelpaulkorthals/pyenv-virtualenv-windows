var searchData=
[
  ['8_20a5_20secure_20system_20design_20b_0',['CON.8.A5 Secure System Design (B)',['../index.html#autotoc_md71',1,'']]],
  ['8_20a6_20use_20of_20external_20libraries_20from_20trusted_20sources_20b_1',['CON.8.A6 Use of External Libraries from Trusted Sources (B)',['../index.html#autotoc_md72',1,'']]]
];
