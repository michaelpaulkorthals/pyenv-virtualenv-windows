var searchData=
[
  ['venv_0',['Python Venv',['../index.html#autotoc_md31',1,'']]],
  ['version_1',['Version',['../index.html#autotoc_md99',1,'Engineer a New Version'],['../index.html#autotoc_md82',1,'Global Python Version']]],
  ['version_20and_20name_2',['Create with Version and Name',['../index.html#autotoc_md22',1,'']]],
  ['virtual_20environment_3',['Virtual Environment',['../index.html#autotoc_md25',1,'Activate Virtual Environment'],['../index.html#autotoc_md21',1,'Create Virtual Environment'],['../index.html#autotoc_md96',1,'Creating Python Virtual Environment'],['../index.html#autotoc_md26',1,'Delete Installed Virtual Environment'],['../index.html#autotoc_md102',1,'Python Virtual Environment']]],
  ['virtual_20environment_20prefix_4',['Virtual Environment Prefix',['../index.html#autotoc_md29',1,'']]],
  ['virtual_20environments_5',['List Installed Virtual Environments',['../index.html#autotoc_md24',1,'']]],
  ['virtualenv_20for_20windows_6',['Plugin &apos;pyenv-virtualenv&apos; for Windows',['../index.html',1,'']]]
];
